@echo off
setlocal
cd /d "%~dp0"
set "ROM=%~1"
if not defined ROM set "ROM=%~dp0Doom Troopers (USA).md"
if not exist "%ROM%" (
  echo ROM nao encontrada.
  echo.
  echo Copie a ROM para esta pasta com o nome:
  echo Doom Troopers ^(USA^).md
  echo.
  echo Ou arraste o arquivo da ROM sobre Jogar.bat.
  pause
  exit /b 1
)
set "GENESIS_STRICT_JSR_STACK=1"
start "Doom Troopers PC Recomp" /wait "%~dp0DoomBootProbe.exe" "%ROM%"
exit /b %errorlevel%
